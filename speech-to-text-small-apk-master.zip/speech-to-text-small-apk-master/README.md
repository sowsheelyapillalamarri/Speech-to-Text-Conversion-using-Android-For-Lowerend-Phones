# speech-to-text-small-apk
speech to text conversion in android where apk will work in lower end phones from Android 1.0
